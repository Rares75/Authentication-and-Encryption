#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "cryptlib.h"
#include "hex.h"
#include "sha.h"
#include "osrng.h"
#include "Users.h"
using namespace CryptoPP;

   std::string Users::testpassword(std::string pass)
    {
        while (true)
        {
            bool test = true;

            if (pass.size() < 8)
            {
                std::cerr << "Minimum length is 8 characters.\n";
                test = false;
            }

            if (pass.find_first_of("QWERTYUIOPASDFGHJKLZXCVBNM") == std::string::npos)
            {
                std::cerr << "Password needs at least one uppercase letter.\n";
                test = false;
            }

            if (pass.find_first_of("!@#$%^&*?/.,") == std::string::npos)
            {
                std::cerr << "Password needs at least one special character.\n";
                test = false;
            }

            if (pass.find_first_of("1234567890") == std::string::npos)
            {
                std::cerr << "Password needs at least one numeric character.\n";
                test = false;
            }

            if (test)
            {
                return pass;
            }

            else
            {
                std::cout << "Enter a new password: ";
                std::cin >> pass;
            }
        }
    }
    Users::Users(std::string name, std::string pass, std::ofstream& fout) :username(name)
    {
        
            password = testpassword(pass);
            fout << username << ' ';
            AddSalt(fout);
    }
    
    void Users::AddSalt(std::ofstream& fout)
    {
        AutoSeededRandomPool prng;
        byte salt[32];
        prng.GenerateBlock(salt, sizeof(salt));
        std::string saltBin(reinterpret_cast<const char*>(salt), sizeof(salt));
        std::string saltStr;
        (void)CryptoPP::StringSource(saltBin, true, new HexEncoder(new StringSink(saltStr)));
        fout << saltStr << std::endl;
        this->saltStr = saltStr;
        crypt(saltStr, fout);

    }
    void Users::crypt(std::string saltStr, std::ofstream& fout)
    {
        SHA256 crypted;
        std::string input = this->password + saltStr;
        std::string encodedinput;
        std::string encodedpass;
        (void)CryptoPP::StringSource(input, true, new HashFilter(crypted, new StringSink(encodedinput)));
        (void)CryptoPP::StringSource(encodedinput, true, new HexEncoder(new StringSink(encodedpass)));
        fout << encodedpass << std::endl;
        this->EncodedPass = encodedpass;
        this->password.clear();

    }
    bool Users::cautare_user(std::string user)
    {
        return this->username == user;
   }
    std::string Users::SaltReturn()
    {
        return this->saltStr;
    }
    std::string Users::HashReturn()
    {
        return this->EncodedPass;
    }