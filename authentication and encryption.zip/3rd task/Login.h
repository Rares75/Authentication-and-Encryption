#pragma once
#include <iostream>
#include <string>

void SearchUser(std::string username, std::string password);