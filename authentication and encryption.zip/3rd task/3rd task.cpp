#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "cryptlib.h"
#include "hex.h"
#include "sha.h"
#include "osrng.h"
#include "Users.h"
#include "Login.h"
using namespace CryptoPP;

std::vector<Users> u;
int main()
{
    std::ofstream fout("baza_de_date.txt");
    Users Maria("Maria Rosu", "KillaFonic1998*", fout);
    u.push_back(Maria);
    Users user1("Andrei Popescu", "Parola123#", fout);
    u.push_back(user1);

    Users user2("Ioana Marinescu", "abcDEF456?", fout);
    u.push_back(user2);

    Users user3("Mihai Georgescu", "SecurePass!2025", fout);
    u.push_back(user3);

    Users user4("Elena Ionescu", "Elena@1234", fout);
    u.push_back(user4);

    Users user5("Cristina Pavel", "MySecret#77", fout);
    u.push_back(user5);
    std::string username;
    std::string password;
    std::cout << "Bine ai Venit!" << std::endl;
    std::cout << "Te rugam sa introduci usernameul si parola:" << std::endl;
    std::cout << "Username:";
    std::getline(std::cin, username);
    std::cout << "password:";
    std::getline(std::cin, password);
    SearchUser(username, password);

}


