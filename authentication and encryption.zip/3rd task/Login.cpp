﻿#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include "cryptlib.h"
#include "hex.h"
#include "sha.h"
#include "osrng.h"
#include <sstream>
#include "Login.h"
#include "Users.h"
using namespace CryptoPP;
static void PasswordVerify(std::string password, std::string salt, std::string hash)
{
    int tries = 0;
    while (true&&tries<3)
    {
        std::string input = password + salt; 
        std::string newhash;
        SHA256 crypted;
        std::string encodedinput;
        (void)CryptoPP::StringSource(input, true, new HashFilter(crypted, new StringSink(encodedinput)));
        (void)CryptoPP::StringSource(encodedinput, true, new HexEncoder(new StringSink(newhash)));

        if (newhash == hash) {
            std::cout << "Logare cu succes!" << std::endl;
            break;
        }
        else
        {
            tries++;
            std::cout << "Parola incorecta, va rugam sa reintroduceti parola: ";
            std::cin >> password;
        }
        if (tries > 3) std::cout << "parola introdusa de prea multe ori,reveniti mai tarziu";
    }
}
void SearchUser(std::string username,std::string password)
{
	std::string salt;
	std::string hash;
	std::ifstream fin("baza_de_date.txt");
    bool found = false;
    while (!found)
    {
        for (auto& i : u)
        {
            if (i.cautare_user(username))
            {
                salt = i.SaltReturn();
                hash = i.HashReturn();
                found = true;
                break;
            }
        }
        if (!found)
        {
            std::cout << "username negasit,va rugam sa il reintroduceti" << ' ';
            std::cin >> username;
            found = false;
        }
    }
	PasswordVerify(password, salt, hash);
  
}
 