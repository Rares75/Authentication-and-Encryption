#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "cryptlib.h"
#include "hex.h"
#include "sha.h"
#include "osrng.h"

using namespace CryptoPP;
class Users
{
private:
    std::string username;
    std::string password;
    std::string saltStr;
    std::string EncodedPass;
public:
    std::string testpassword(std::string pass);
    
    Users(std::string name, std::string pass, std::ofstream& fout);
    void AddSalt(std::ofstream& fout);
  
    void crypt(std::string saltStr, std::ofstream& fout);
    bool cautare_user(std::string user);
    std::string SaltReturn();
    std::string HashReturn();
};
extern std::vector<Users> u;