#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cstring>
#include <cmath>
std::ofstream fout1("date.txt");
 std::fstream fout;
std::fstream fin;
std::ifstream fin1("date.txt");
class Date_persoane
{
    private:
    std::string nume;
    std::string parola;
    int lungime_nume;
    int lungime_parola;
    int varsta;

    public:
    Date_persoane(std::string nume_in,std::string parola_in,int varsta_in)
    {
        this->nume=nume_in;
        this->parola=parola_in;
        this->varsta=varsta_in;
        this->lungime_nume=nume_in.length();
        this->lungime_parola=parola_in.length();
    }

    void afisare()
    {
       fout1<<this->nume<<' '<<this->parola<<' '<<this->varsta<<std::endl;
    }
   void scriere_binara()
   {
         size_t len = nume.length();
         fout.write(reinterpret_cast<const char*>(&len), sizeof(len)); // Scrie lungimea
         fout.write(nume.c_str(), len);
         len = parola.length();
         fout.write(reinterpret_cast<const char*>(&len), sizeof(len)); // Scrie lungimea
         fout.write(parola.c_str(), len);
         fout.write(reinterpret_cast<char*>(&varsta),sizeof(int));
   }
   /*void reconstruire_binar()
   {
    size_t len=this->lungime_nume;
    int aux=0;
    int i;
    int x;
    for(i=0;i<len;i++)
    {
        fin>>x;
        aux=aux*10+x;
    }
    std::string nume_din_binar=std::to_string(x);
    aux=0;
    len=this->lungime_parola;
    for(;i<len;i++)
    {
        fin>>x;
        aux=aux*10+x;
    }
    std::string parola_din_binar=std::to_string(x);
    int power=3;
    int nr=0;
    while(fin>>x)
    {
        nr=nr*10+x*pow(10,power);
        power--;
    }
    std::cout<<nume_din_binar<<' '<<parola_din_binar<<' '<<nr<<std::endl;
   }*/
   static void citesteToateDinBinar() {
        fin.clear(); // Resetează starea fișierului
        fin.seekg(0); // Mergi la începutul fișierului
        
        while (!fin.eof()) {
            size_t len;
            // Încearcă să citești lungimea numelui
            fin.read(reinterpret_cast<char*>(&len), sizeof(len));
            if (fin.eof()) break; // Ieși dacă am ajuns la sfârșit
            
            std::string nume(len, ' ');
            fin.read(&nume[0], len);
            
            fin.read(reinterpret_cast<char*>(&len), sizeof(len));
            std::string parola(len, ' ');
            fin.read(&parola[0], len);
            
            int varsta;
            fin.read(reinterpret_cast<char*>(&varsta), sizeof(varsta));
            
            // Afișează datele citite
            std::cout << nume << ' ' << parola << ' ' << varsta << std::endl;
        }
    }
    static void CitesteDinText()
    {
       std::string x;
       while(std::getline(fin1,x,'\n'))
       {
        std::cout<<x<< std::endl;
       }

    }
};
int main()
{
      Date_persoane Alina("Alina Popescu", "alina123", 20);
      Alina.afisare();
      std::vector<Date_persoane> persoane={
        {"andrei ionescu","andrei123",33},
        {"maria rosu","killafoniciubitumeu23",21},
        {"marius andrei","labacuc2327",45}
      };
      
      for(auto& x:persoane)
      x.afisare();
     
      fout.open("fisier_binar.dat",std::ios::out | std::ios::binary);
      if(fout)
      {
         Alina.scriere_binara();
         for(auto& x:persoane)
         x.scriere_binara();
         fout.close();
      }
      else 
      std::cerr<<"EROARE LA DESCHIDEREA FISIERULUI";
      std::cout<<"afisare din binar"<<std::endl;
      fin.open("fisier_binar.dat", std::ios::in | std::ios::binary);
    if (fin) {
        Date_persoane::citesteToateDinBinar(); // Citește toate datele
        fin.close();
    } else {

        std::cerr << "EROARE LA DESCHIDEREA FISIERULUI";
    }
    std::cout<<"----------------------"<<std::endl;
    std::cout<<"afisare din txt"<<std::endl;
    Date_persoane::CitesteDinText();

   return 0;

}