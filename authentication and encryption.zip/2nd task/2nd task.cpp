﻿#include "cryptlib.h"
#include "sha.h"
#include "filters.h"
#include "hex.h"
#include "osrng.h"
#include <iostream>
#include <string>
#include <fstream>
std::ofstream fout("baza_de_date.txt");
std::ofstream fout1("parole_criptate.txt");
class Person
{
private:
	std::string username;
	std::string password;
	std::string SaltPassword;
	std::string encodedpass;
public:
	Person(std::string name, std::string pass) :username(name), password(pass)
	{
		fout << this->username << ' ' << this->password;
		CryptoPP::AutoSeededRandomPool prng; //genereaza un numar aleator de caractere cryptografice
		CryptoPP::byte salt[16];
		prng.GenerateBlock(salt, sizeof(salt));
		std::string saltStr(reinterpret_cast<const char*>(salt), sizeof(salt));
		this->SaltPassword = saltStr + password;
		std::string encoded;
		CryptoPP::StringSource(this->SaltPassword, true,
			new CryptoPP::HexEncoder(
				new CryptoPP::StringSink(encoded)
			)
		);
		this->encodedpass = encoded;
		fout << encoded << std::endl;


	}
	const void afisare() const
	{
		std::cout << this->username << ' ' << this->password;
	}
	static void crypt(Person& x)
	{
		
		CryptoPP::SHA256 criptat;
		std::string digest;
		CryptoPP::StringSource(x.SaltPassword, true, new CryptoPP::HashFilter(criptat, new CryptoPP::StringSink(digest)));
		std::string encodedHash;
		CryptoPP::StringSource(digest, true,
			new CryptoPP::HexEncoder(
				new CryptoPP::StringSink(encodedHash)
			)
		);

		// Salvează în fișier: username + hash hex
		fout1 << x.username << ": " << encodedHash << std::endl;
	}

};
int main() 
{
	Person M("Maria", "iliubescpecaba123");
	Person C("alin", "alinjmkparkour");
	Person::crypt(M);
	Person::crypt(C);
	return 0;
}